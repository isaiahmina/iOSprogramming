//
//  ViewController.swift
//  Checklist
//
//  Created by isaiah on 3/12/19.
/*
 1. The application works, as far as creating a basic table view and displaying a cell with some text inside
 2. I was unable to deploy the app to an iphone
 3. The application creates a basic table view with a cell, and contains code to set the text of the cell depending on what cell position it is
 4. I added a few extra cells and gave them different details
 5. I learned a bit about table views in this section, and about how widely used and useful they are in applications
 6. No other materials were consulted
*/


import UIKit

class ChecklistViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    //called every time a table view needs a cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChecklistItem", for: indexPath)
        
        if let label = cell.viewWithTag(1000) as?UILabel{   //grabs the cell with tag #1000 and casts it as a UILabel
            if indexPath.row == 0{
                label.text = "run a marathon"
            }else if indexPath.row == 1{
                label.text = "go to sleep"
            }else{
                label.text = "eat a doughnut"
            }
        }
        
        return cell
    }
    
}

