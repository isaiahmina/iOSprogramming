//
//  AboutViewController.swift
//  bullseye_mina
//
//  Created by isaiah on 2/14/19.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func close() {
        dismiss(animated: true, completion: nil)
    }
}
