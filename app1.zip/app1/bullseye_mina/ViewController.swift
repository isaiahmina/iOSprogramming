//
//  ViewController.swift
//  bullseye_mina
//
/*
1. The application works, with some bugs. The addition of the closure for postponing the startnewround method causes my application to not start a new round, until another button is pressed after the alert is dismissed. For example, after tapping 'hit me' once, nothing will change. but after hitting the little 'i' button in the lower right, everything will update. I can't find out why this happens, as my code is the same as in the video except for having different variable names.
2. I do not have an iPhone to deploy the app to
3. The app now can restart properly and has an info screen. The delayed startnewround closure is buggy however (see comment 1 and comments below in the code)
4. I modified the score to be out of 1000 instead of 100
5. I learned about swift closures and how to create additional screens
6. No other material was consulted other than the videos
7. None
*/

//

import UIKit

class ViewController: UIViewController {

    var currentVal = 0
    var targetVal = 0
    var roundNum = 0
    var score = 0
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var target: UILabel!
    @IBOutlet weak var round: UILabel!
    @IBOutlet weak var scoreLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let roundedValue = slider.value.rounded()
        currentVal = Int(roundedValue)
        startNewRound()
    }

    @IBAction func showAlert(){
        
        let difference = abs(targetVal - currentVal)
        var points = (100 - difference)*10
        
        score += points
        
        let title: String
        if difference == 0{
            title = "Perfect!"
            points += 1000
        }else if difference < 5 {
            title = "Just missed it..."
            if difference == 1{
                points += 500
            }
        }else if difference < 10 {
            title = "Almost there!"
        }else{
            title = "Did you even aim?"
        }
        
        let message = "You scored \(points) points"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        //the bug mentioned in the above comments exists here; if I were to set handler to nil and un-comment the startNewRound method call below the present() command everthing will work fine
        let action = UIAlertAction(title:"OK", style: .default, handler: {
            action in
            self.startNewRound()
        })
        
        alert.addAction(action);
        
        present(alert, animated: true, completion: nil)
        //startNewRound()
    }
    
    @IBAction func sliderMoved(_ slider: UISlider){
        let roundedValue = slider.value.rounded();
        currentVal = Int(roundedValue);
    }
    
    func startNewRound(){
        targetVal = Int.random(in: 1...100)
        currentVal = 50
        slider.value = Float(currentVal)
        roundNum += 1
        updateLabels()
    }
    func updateLabels(){
        target.text = String(targetVal)
        round.text = String(roundNum)
        scoreLabel.text = String(score)
    }
    
    @IBAction func restart (){
        roundNum = 0
        score = 0
        startNewRound()
    }
}
