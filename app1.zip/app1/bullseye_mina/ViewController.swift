//
//  ViewController.swift
//  bullseye_mina
//
/*
1. The application works, and is styled using various options
2. I do not have an iPhone to deploy the app to
3. I styled the app and changed some code to work out bugs that were in a previous version
4. I used different styles, such as colors and object locations
5. I learned about styling an app in swift, as well as how constraints work
6. No other material was consulted other than the videos
7. None
*/

//

import UIKit

class ViewController: UIViewController {

    var currentVal = 0
    var targetVal = 0
    var roundNum = 0
    var score = 0
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var target: UILabel!
    @IBOutlet weak var round: UILabel!
    @IBOutlet weak var scoreLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let roundedValue = slider.value.rounded()
        currentVal = Int(roundedValue)
        startNewRound()
        
        let thumbImageNormal = #imageLiteral(resourceName: "SliderThumb-Normal")
        slider.setThumbImage(thumbImageNormal, for: .normal)
        
        let thumbImageHighlighted=#imageLiteral(resourceName: "SliderThumb-Highlighted")
        slider.setThumbImage(thumbImageHighlighted, for: .highlighted)
        
        let insets = UIEdgeInsets(top: 0, left: 14, bottom: 0, right: 14)
        
        let trackLeftImage = #imageLiteral(resourceName: "SliderTrackLeft")
        let trackLeftResizable = trackLeftImage.resizableImage(withCapInsets: insets)
        slider.setMinimumTrackImage(trackLeftResizable, for: .normal)
        
        let trackRightImage = #imageLiteral(resourceName: "SliderTrackRight")
        let trackRightResizable = trackRightImage.resizableImage(withCapInsets: insets)
        slider.setMaximumTrackImage(trackRightResizable, for: .normal)
        
    }

    @IBAction func showAlert(){
        
        let difference = abs(targetVal - currentVal)
        var points = (100 - difference)*10
        
        score += points
        
        let title: String
        if difference == 0{
            title = "Perfect!"
            points += 1000
        }else if difference < 5 {
            title = "Just missed it..."
            if difference == 1{
                points += 500
            }
        }else if difference < 10 {
            title = "Almost there!"
        }else{
            title = "Did you even aim?"
        }
        
        let message = "You scored \(points) points"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        //the bug mentioned in the above comments exists here; if I were to set handler to nil and un-comment the startNewRound method call below the present() command everthing will work fine
        let action = UIAlertAction(title:"OK", style: .default, handler:nil)
        /*{
            action in
            self.startNewRound()
        })
        */
        alert.addAction(action);
        
        present(alert, animated: true, completion: nil)
        startNewRound()
    }
    
    @IBAction func sliderMoved(_ slider: UISlider){
        let roundedValue = slider.value.rounded();
        currentVal = Int(roundedValue);
    }
    
    func startNewRound(){
        targetVal = Int.random(in: 1...100)
        currentVal = 50
        slider.value = Float(currentVal)
        roundNum += 1
        updateLabels()
    }
    func updateLabels(){
        target.text = String(targetVal)
        round.text = String(roundNum)
        scoreLabel.text = String(score)
    }
    
    @IBAction func restart (){
        roundNum = 0
        score = 0
        startNewRound()
    }
}
