//
//  ViewController.swift
//  bullseye_mina
//
/*
1. The application works
2. I do not have an iPhone to deploy the app to
3. The app now is properly linked to display the round number and the current accumulated score. The score is calculated by finding the difference between the target number and the actual number, then multiplying that value by 10 in order to make it out of 1000 instead of 100. If the hit was perfect, an additional 1000 points are added to that round's score. If it was off by 1, then 500 points are added instead.
4. I modified the score to be out of 1000 instead of 100
5. I learned the difference between the 'var' and 'let' assignments for variables in swift
6. No other material was consulted other than the videos
7. None
*/

//

import UIKit

class ViewController: UIViewController {

    var currentVal = 0
    var targetVal = 0
    var roundNum = 0
    var score = 0
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var target: UILabel!
    @IBOutlet weak var round: UILabel!
    @IBOutlet weak var scoreLabel : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let roundedValue = slider.value.rounded()
        currentVal = Int(roundedValue)
        startNewRound()
    }

    @IBAction func showAlert(){
        
        let difference = abs(targetVal - currentVal)
        var points = (100 - difference)*10
        
        score += points
        
        let title: String
        if difference == 0{
            title = "Perfect!"
            points += 1000
        }else if difference < 5 {
            title = "Just missed it..."
            if difference == 1{
                points += 500
            }
        }else if difference < 10 {
            title = "Almost there!"
        }else{
            title = "Did you even aim?"
        }
        
        let message = "You scored \(points) points"
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        
        present(alert, animated: true, completion: nil)
        
        startNewRound()
        
    }
    
    @IBAction func sliderMoved(_ slider: UISlider){
        let roundedValue = slider.value.rounded();
        currentVal = Int(roundedValue);
    }
    
    func startNewRound(){
        targetVal = Int.random(in: 1...100)
        currentVal = 50
        slider.value = Float(currentVal)
        roundNum += 1
        updateLabels()
    }
    func updateLabels(){
        target.text = String(targetVal)
        round.text = String(roundNum)
        scoreLabel.text = String(score)
    }
}
